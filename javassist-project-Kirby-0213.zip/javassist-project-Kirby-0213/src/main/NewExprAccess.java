package main;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.Scanner;

import javassist.CannotCompileException;
import javassist.ClassClassPath;
import javassist.ClassPool;
import javassist.CtClass;
import javassist.CtField;
import javassist.NotFoundException;
import javassist.expr.ExprEditor;
import javassist.expr.NewExpr;

public class NewExprAccess extends ClassLoader {
	static String _L_ = System.lineSeparator();
	private ClassPool pool;
	static String className;
	static int fieldNum;

	public static void main(String[] args) throws Throwable {
		Scanner sc = new Scanner(System.in);
		String[] list;
		boolean quit = false;

		do {
			System.out.println(
					"Please enter an application class name and the number of method fields to be analyzed and displayed--separated by a comma.\n"
							+ "(e.g. ComponentApp, 1 or ServiceApp, 100)\n" + "Key \\\"q\\\" to quit.");
			String input = sc.nextLine();
			list = input.split(",");
			for (int i = 0; i < list.length; i++) {
				list[i] = list[i].trim();
				if (list[i].equals("q")) {
					System.out.println("You have quit the program.");
					sc.close();
					System.exit(0);
				}
			}
			System.out.println("");

			if (list.length != 2) {
				System.out.println("[WRN] Invalid Input size!!\n");
				for (int i = 0; i < list.length; i++) {
					list[i] = null;
				}
			} else {
				className = "target." + list[0];
				fieldNum = Integer.parseInt(list[1]);

				try {
					NewExprAccess s = new NewExprAccess();
					Class<?> c = s.findClass(className);
					Method mainMethod = c.getDeclaredMethod("main", new Class[] { String[].class });
					mainMethod.invoke(null, new Object[] { args });
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			System.out.println("---------------------------------------------------------------");
		} while (!quit);
	}

	public NewExprAccess() throws NotFoundException {
		pool = new ClassPool();
		pool.insertClassPath(new ClassClassPath(new java.lang.Object().getClass()));
	}

	/*
	 * Finds a specified class. The bytecode for that class can be modified.
	 */
	protected Class<?> findClass(String name) throws ClassNotFoundException {
		CtClass cc = null;
		try {
			cc = pool.get(name);
			cc.instrument(new ExprEditor() {
				public void edit(NewExpr newExpr) throws CannotCompileException {

					try {
						String longName = newExpr.getConstructor().getLongName();
						if (longName.startsWith("java.")) {
							return;
						}
					} catch (NotFoundException e) {
						e.printStackTrace();
					}
					CtField[] fields = newExpr.getEnclosingClass().getDeclaredFields();
					String log = String.format("[Edited by ClassLoader] new expr: %s, " + "line: %d, signature: %s",
							newExpr.getEnclosingClass().getName(), newExpr.getLineNumber(), newExpr.getSignature());
					System.out.println(log);

					StringBuilder block = new StringBuilder();
					block.append("{" + _L_ + " $_ = $proceed($$);" + _L_);
					for (int i = 0; i < fields.length && i < fieldNum; i++) {
						try {
							String fieldName = fields[i].getName();
							String fieldType = fields[i].getType().getName();

							block.append("   {" + _L_);
							block.append("    String cName = $_.getClass().getName();" + _L_);
							block.append(
									"    String fName = $_.getClass().getDeclaredFields()[" + i + "].getName();" + _L_);
							block.append("    String fieldFullName = cName + \".\" + fName;" + _L_);
							block.append("    " + fieldType + " fieldValue = $_." + fieldName + ";" + _L_);
							block.append(
									"    System.out.println(\"  [Instrument] \" + fieldFullName + \": \" + fieldValue"
											+ ");" + _L_);
							block.append("   }" + _L_);
						} catch (NotFoundException e) {
							e.printStackTrace();
						}
					}

					block.append("}");
					System.out.println(block);
					newExpr.replace(block.toString());
				}
			});
			byte[] b = cc.toBytecode();
			return defineClass(name, b, 0, b.length);
		} catch (NotFoundException e) {
			throw new ClassNotFoundException();
		} catch (IOException e) {
			throw new ClassNotFoundException();
		} catch (CannotCompileException e) {
			e.printStackTrace();
			throw new ClassNotFoundException();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
}